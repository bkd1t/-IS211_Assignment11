from flask import Flask, render_template, redirect, url_for, request
app=Flask(__name__)


@app.route('/delete/<pk>', methods = ['POST', 'GET'])
def delete(pk):
    id=pk
    con = sqlite3.connect("database.db")
    with con:
        cur = con.cursor()
        cur.execute('DELETE FROM todo WHERE id = (?)', (id))
        con.commit()
    return redirect('/')
    

@app.route('/')
def hello_world():
    name=None
    con = sqlite3.connect("database.db")
    con.row_factory = sqlite3.Row
    cur = con.cursor()
    cur.execute("select * from todo")
    rows = cur.fetchall(); 
    return render_template('hello.html', rows=rows)


@app.route('/create',methods = ['POST', 'GET'])
def create():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        priority = request.form['select']
        print (priority)
        con = sqlite3.connect("database.db")
        id = None
        with con:
            cur = con.cursor()
            cur.execute('INSERT INTO todo VALUES(?, ?, ?, ?)', (id, name, email, priority))
            con.commit()

        con = sqlite3.connect("database.db")
        con.row_factory = sqlite3.Row
        cur = con.cursor()
        cur.execute("select * from todo")
        rows = cur.fetchall(); 

        return render_template('hello.html', rows=rows)
    else:
        return render_template('create_todo.html')
    

if __name__=='__main__':
    import sqlite3
    conn = sqlite3.connect('database.db')
    conn.execute('CREATE table if not exists todo (id INTEGER NOT NULL PRIMARY KEY, name text NOT NULL, email varchar, priority varchar)')
    conn.close()
    app.run()
    # export FLASK_ENV=development



# from flask import Flask, render_template
# app = Flask(__name__)

# @app.route('/')
# def index():
#     return 'Index Page'

# @app.route('/hello')
# def hello():
#     name=None
#     return render_template('hello.html', name=name)